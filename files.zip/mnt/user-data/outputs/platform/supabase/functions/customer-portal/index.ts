// Πύλη διαχείρισης συνδρομής Stripe (ακύρωση, αλλαγή κάρτας, αποδείξεις). Απαιτεί ενεργοποίηση του Customer portal στο Stripe Dashboard.
const SB = Deno.env.get('SUPABASE_URL')!, SERVICE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, ANON = Deno.env.get('SUPABASE_ANON_KEY')!;
const STRIPE = Deno.env.get('STRIPE_SECRET_KEY')!, SITE = (Deno.env.get('SITE_URL') || '').replace(/\/$/, '');
const cors = { 'Access-Control-Allow-Origin': new URL(SITE).origin, 'Access-Control-Allow-Headers': 'authorization, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS', Vary: 'Origin' };
const json = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, 'Content-Type': 'application/json' } });
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const jwt = (req.headers.get('Authorization') || '').replace('Bearer ', '');
    const ur = await fetch(`${SB}/auth/v1/user`, { headers: { apikey: ANON, Authorization: `Bearer ${jwt}` } });
    if (!ur.ok) return json({ error: 'Απαιτείται σύνδεση' }, 401);
    const user = await ur.json();
    const prof = (await (await fetch(`${SB}/rest/v1/profiles?id=eq.${user.id}&select=stripe_customer_id`, { headers: { apikey: SERVICE, Authorization: `Bearer ${SERVICE}` } })).json())[0];
    if (!prof?.stripe_customer_id) return json({ error: 'Δεν βρέθηκε συνδρομή' }, 404);
    const r = await fetch('https://api.stripe.com/v1/billing_portal/sessions', { method: 'POST', headers: { Authorization: `Bearer ${STRIPE}`, 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ customer: prof.stripe_customer_id, return_url: `${SITE}/account/` }) });
    const j = await r.json(); if (!r.ok) throw new Error(j.error?.message);
    return json({ url: j.url });
  } catch (e) { console.error(e); return json({ error: 'Δεν ήταν δυνατό το άνοιγμα της πύλης' }, 500); }
});
